const conn = require('../database');
const moment = require('moment');

exports.list = async function(req, res){
    var topweapons = [];
    var results = [];
    conn.query("SELECT * FROM games", function(err, result) {
        if (err) throw err;
        for (let i = 0; i < result.length; i++) {
            var startDate = result[i].created_at;
            var timeInSeconds = calculateDays(startDate,new Date());
            var seconds = Math.floor(timeInSeconds%60);
            var minutes = Math.round(timeInSeconds/60);
            if ((minutes/60)>24){
                result[i].created_at =" > 1 day";
            } else {
                if((minutes/60)>1){
                    var hours = Math.round(minutes/60);
                    minutes = Math.floor((timeInSeconds/60)%60);
                    if(seconds<10)
                        seconds="0"+seconds;
                    if(minutes<10)
                        minutes="0"+minutes;
                    result[i].created_at =hours+":"+minutes+":"+seconds+" ago";
                } else {
                    if(seconds<10)
                        seconds="0"+seconds;
                    if(minutes<10)
                        minutes="0"+minutes;
                    result[i].created_at = minutes+":"+seconds+" ago";
                }

            }
            if (result[i].mic === "yes") {
                result[i].mic = "🎤";
            } else {
                result[i].mic = "";
            }

        }
        results = results.concat(result);
        conn.query("SELECT * FROM topweapons", function(err, result) {
            if (err) throw err;
            topweapons = topweapons.concat(result);
            console.log(topweapons[0].rank1);
            res.render('index',{page_title:"Test Table",data:results,weapons:topweapons});
        });

            });
};
function calculateDays(startDate,endDate)
{
    var start_date = moment(startDate, 'YYYY-MM-DD HH:mm:ss');
    var end_date = moment(endDate, 'YYYY-MM-DD HH:mm:ss');
    var duration = moment.duration(end_date.diff(start_date));
    var days = duration.asSeconds();
    return days;
}
