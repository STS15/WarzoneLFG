var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var flash = require('express-flash');
var session = require('express-session');
var db=require('./database');
var testtable = require('./routes/testtable');
var profanity = require('@2toad/profanity').profanity;
const API = require('call-of-duty-api')({platform: "all"});

var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');
app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(flash());
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
    secret: '123456catr',
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 60000 }
}))

app.get('/', testtable.list, function(req, res, next) {
    res.render('index');
});

app.post('/form-warzone', function(req, res, next) {
    var platform = req.body.platform;
    var region = req.body.region;
    var language = req.body.language;
    var activity = req.body.activity;
    var skill = req.body.skill;
    var captcha = req.body.text;
    var ip = req.body.ipAddress;
    var userAgent = req.body.userAgent;
    var os = req.body.os;
    var referrer = req.body.referrer;
    var historyLen = req.body.historyLen;
    var screenWidth = req.body.screenWidth;
    var screenHeight = req.body.screenHeight;
    var cookie = req.body.cookie;
    var city = req.body.city;
    var state = req.body.state;
    var country = req.body.country;
    var mic;
    var gamertag = req.body.gamertag;
    if(req.body.mic === "mic") {
        mic = "yes";
    } else {
        mic = "no";
    }
    profanity.addWords(["4r5e", "5h1t", "5hit", "a55", "anal", "anus", "ar5e", "arrse", "arse", "ass", "ass-fucker", "asses", "assfucker", "assfukka", "asshole", "assholes", "asswhole", "a_s_s", "b!tch", "b00bs","boob","bitch", "b17ch", "b1tch", "ballbag", "balls", "ballsack", "bastard", "beastial", "beastiality", "bellend", "bestial", "bestiality", "bi+ch", "biatch", "bitch", "bitcher", "bitchers", "bitches", "bitchin", "bitching", "bloody", "blow job", "blowjob", "blowjobs", "boiolas", "bollock", "bollok", "boner", "boob", "boobs", "booobs", "boooobs", "booooobs", "booooooobs", "breasts", "buceta", "bugger", "bum", "bunny fucker", "butt", "butthole", "buttmuch", "buttplug", "c0ck", "c0cksucker", "carpet muncher", "cawk", "chink", "cipa", "cl1t", "clit", "clitoris", "clits", "cnut", "cock", "cock-sucker", "cockface", "cockhead", "cockmunch", "cockmuncher", "cocks", "cocksuck", "cocksucked", "cocksucker", "cocksucking", "cocksucks", "cocksuka", "cocksukka", "cok", "cokmuncher", "coksucka", "coon", "cox", "crap", "cum", "cummer", "cumming", "cums", "cumshot", "cunilingus", "cunillingus", "cunnilingus", "cunt", "cuntlick", "cuntlicker", "cuntlicking", "cunts", "cyalis", "cyberfuc", "cyberfuck", "cyberfucked", "cyberfucker", "cyberfuckers", "cyberfucking", "d1ck", "damn", "dick", "dickhead", "dildo", "dildos", "dink", "dinks", "dirsa", "dlck", "dog-fucker", "doggin", "dogging", "donkeyribber", "doosh", "duche", "dyke", "ejaculate", "ejaculated", "ejaculates", "ejaculating", "ejaculatings", "ejaculation", "ejakulate", "f u c k", "f u c k e r", "f4nny", "fag", "fagging", "faggitt", "faggot", "faggs", "fagot", "fagots", "fags", "fanny", "fannyflaps", "fannyfucker", "fanyy", "fatass", "fcuk", "fcuker", "fcuking", "feck", "fecker", "felching", "fellate", "fellatio", "fingerfuck", "fingerfucked", "fingerfucker", "fingerfuckers", "fingerfucking", "fingerfucks", "fistfuck", "fistfucked", "fistfucker", "fistfuckers", "fistfucking", "fistfuckings", "fistfucks", "flange", "fook", "fooker", "fuck", "fucka", "fucked", "fucker", "fuckers", "fuckhead", "fuckheads", "fuckin", "fucking", "fuckings", "fuckingshitmotherfucker", "fuckme", "fucks", "fuckwhit", "fuckwit", "fudge packer", "fudgepacker", "fuk", "fuker", "fukker", "fukkin", "fuks", "fukwhit", "fukwit", "fux", "fux0r", "f_u_c_k", "gangbang", "gangbanged", "gangbangs", "gaylord", "gaysex", "goatse", "God", "god-dam", "god-damned", "goddamn", "goddamned", "hardcoresex", "hell", "heshe", "hoar", "hoare", "hoer", "homo", "hore", "horniest", "horny", "hotsex", "jack-off", "jackoff", "jap", "jerk-off", "jism", "jiz", "jizm", "jizz", "kawk", "knob", "knobead", "knobed", "knobend", "knobhead", "knobjocky", "knobjokey", "kock", "kondum", "kondums", "kum", "kummer", "kumming", "kums", "kunilingus", "l3i+ch", "l3itch", "labia", "lust", "lusting", "m0f0", "m0fo", "m45terbate", "ma5terb8", "ma5terbate", "masochist", "master-bate", "masterb8", "masterbat*", "masterbat3", "masterbate", "masterbation", "masterbations", "masturbate", "mo-fo", "mof0", "mofo", "mothafuck", "mothafucka", "mothafuckas", "mothafuckaz", "mothafucked", "mothafucker", "mothafuckers", "mothafuckin", "mothafucking", "mothafuckings", "mothafucks", "mother fucker", "motherfuck", "motherfucked", "motherfucker", "motherfuckers", "motherfuckin", "motherfucking", "motherfuckings", "motherfuckka", "motherfucks", "muff", "mutha", "muthafecker", "muthafuckker", "muther", "mutherfucker", "n1gga", "n1gger", "nazi", "nigg3r", "nigg4h", "nigga", "niggah", "niggas", "niggaz", "nigger", "niggers", "nob", "nob jokey", "nobhead", "nobjocky", "nobjokey", "numbnuts", "nutsack", "orgasim", "orgasims", "orgasm", "orgasms", "p0rn", "pawn", "pecker", "penis", "penisfucker", "phonesex", "phuck", "phuk", "phuked", "phuking", "phukked", "phukking", "phuks", "phuq", "pigfucker", "pimpis", "piss", "pissed", "pisser", "pissers", "pisses", "pissflaps", "pissin", "pissing", "pissoff", "poop", "porn", "porno", "pornography", "pornos", "prick", "pricks", "pron", "pube", "pusse", "pussi", "pussies", "pussy", "pussys", "rectum", "retard", "rimjaw", "rimming", "s hit", "s.o.b.", "sadist", "schlong", "screwing", "scroat", "scrote", "scrotum", "semen", "sex", "sh!+", "sh!t", "sh1t", "shag", "shagger", "shaggin", "shagging", "shemale", "shi+", "shit", "shitdick", "shite", "shited", "shitey", "shitfuck", "shitfull", "shithead", "shiting", "shitings", "shits", "shitted", "shitter", "shitters", "shitting", "shittings", "shitty", "skank", "slut", "sluts", "smegma", "smut", "snatch", "son-of-a-bitch", "spac", "spunk", "s_h_i_t", "t1tt1e5", "t1tties", "teets", "teez", "testical", "testicle", "tit", "titfuck", "tits", "titt", "tittie5", "tittiefucker", "titties", "tittyfuck", "tittywank", "titwank", "tosser", "turd", "tw4t", "twat", "twathead", "twatty", "twunt", "twunter", "v14gra", "v1gra", "vagina", "viagra", "vulva", "w00se", "wang", "wank", "wanker", "wanky", "whoar", "whore", "willies", "willy", "xrated", "xxx"]);


    // Check if sql should go through
    if (!profanity.exists(gamertag)) {
        // Checks profanity
        if (platform==="PC"){
            // User exists
            try {
                WZdata(gamertag,"battle").then((data) => {
                    try{
                        var kd = data.br.kdRatio.toFixed(2);
                        var wins = data.br.wins;
                        var kills = data.br_all.kills;
                        var sql = `INSERT INTO games (platform, region, language, activity, skill, mic, gamertag, created_at, captcha, ip, userAgent, os, referrer, historyLen, screenWidth, screenHeight, cookie, city, state, country, kd, wins, kills) VALUES ("${platform}", "${region}", "${language}", "${activity}", "${skill}","${mic}","${gamertag}",NOW(),"${captcha}","${ip}","${userAgent}","${os}","${referrer}","${historyLen}","${screenWidth}","${screenHeight}","${cookie}","${city}","${state}","${country}","${kd}","${wins}","${kills}")`;

                        db.query(sql, function(err, result) {
                            if (err) throw err;
                            console.log('Record inserted',platform, region, language, activity, skill, mic, gamertag, ip, kd, wins, kills);
                            req.flash('success', 'Squad Request Sent!');
                            res.redirect('/');
                        });
                    } catch (e) {
                        req.flash('failure', `Username incorrect, please try again`);
                        res.redirect('/');
                    }
                });
            } catch (e) {
                req.flash('failure', `Username doesn't exist`);
                res.redirect('/');
            }
        } else if (platform==="Xbox") {
            try {
                WZdata(gamertag,"xbl").then((data) => {
                    try{
                        var kd = data.br.kdRatio.toFixed(2);
                        var wins = data.br.wins;
                        var kills = data.br_all.kills;
                        var sql = `INSERT INTO games (platform, region, language, activity, skill, mic, gamertag, created_at, captcha, ip, userAgent, os, referrer, historyLen, screenWidth, screenHeight, cookie, city, state, country, kd, wins, kills) VALUES ("${platform}", "${region}", "${language}", "${activity}", "${skill}","${mic}","${gamertag}",NOW(),"${captcha}","${ip}","${userAgent}","${os}","${referrer}","${historyLen}","${screenWidth}","${screenHeight}","${cookie}","${city}","${state}","${country}","${kd}","${wins}","${kills}")`;

                        db.query(sql, function(err, result) {
                            if (err) throw err;
                            console.log('Record inserted',platform, region, language, activity, skill, mic, gamertag, ip, kd, wins, kills);
                            req.flash('success', 'Squad Request Sent!');
                            res.redirect('/');
                        });
                    } catch (e) {
                        req.flash('failure', `Username incorrect, please try again`);
                        res.redirect('/');
                    }
                });
            } catch (e) {
                req.flash('failure', `Username doesn't exist`);
                res.redirect('/');
            }

        } else if (platform==="Playstation") {
            try {
                WZdata(gamertag,"psn").then((data) => {
                    try{
                        var kd = data.br.kdRatio.toFixed(2);
                        var wins = data.br.wins;
                        var kills = data.br_all.kills;
                        var sql = `INSERT INTO games (platform, region, language, activity, skill, mic, gamertag, created_at, captcha, ip, userAgent, os, referrer, historyLen, screenWidth, screenHeight, cookie, city, state, country, kd, wins, kills) VALUES ("${platform}", "${region}", "${language}", "${activity}", "${skill}","${mic}","${gamertag}",NOW(),"${captcha}","${ip}","${userAgent}","${os}","${referrer}","${historyLen}","${screenWidth}","${screenHeight}","${cookie}","${city}","${state}","${country}","${kd}","${wins}","${kills}")`;

                        db.query(sql, function(err, result) {
                            if (err) throw err;
                            console.log('Record inserted',platform, region, language, activity, skill, mic, gamertag, ip, kd, wins, kills);
                            req.flash('success', 'Squad Request Sent!');
                            res.redirect('/');
                        });
                    } catch (e) {
                        req.flash('failure', `Username incorrect or no game data.`);
                        res.redirect('/');
                    }
                });
            } catch (e) {
                req.flash('failure', `Username doesn't exist.`);
                res.redirect('/');
            }
        }
        else {
            // User doesnt exist
            req.flash('failure', `Username doesn't exist.`);
            res.redirect('/');
        }

    } else if (profanity.exists(gamertag)) {
        req.flash('failure', 'Profanity detected in gamertag!');
        res.redirect('/');
    }
    else {
        req.flash('failure', 'Please wait 15 minutes before submitting a second request!');
        res.redirect('/');
    }

});

app.use(function(req, res, next) {
    next(createError(404));
});

app.listen(3000, function () {
    console.log('Node app is running on port 3000');
});

module.exports = app;

async function WZdata(gamertag,platform) {
    try {
        await API.loginWithSSO("MTczNDQ4ODU4OTExODc3NzE4OTg6MTYzNTYzNTEyNzU3NzoyMzU3ODU1M2EzNjQ3ZjBmMWM2OGUxODViYmRmYmFmYw");
        let data = await API.MWBattleData(gamertag, platform);
        return data;
    } catch (e) {
        return false;
    }
}
