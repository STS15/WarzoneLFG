var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var flash = require('express-flash');
var session = require('express-session');
var db=require('./database');
var testtable = require('./routes/testtable');
var axios = require('axios');


var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use(session({
    secret: '123456catr',
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 60000 }
}))

app.use(flash());

/* GET home page. */
app.get('/', testtable.list, function(req, res, next) {
    res.render('index');
});

app.post('/form-warzone', function(req, res, next) {
    var platform = req.body.platform;
    var region = req.body.region;
    var language = req.body.language;
    var activity = req.body.activity;
    var skill = req.body.skill;
    var captcha = req.body.text;
    var ip = req.body.ipAddress;
    var userAgent = req.body.userAgent;
    var os = req.body.os;
    var referrer = req.body.referrer;
    var historyLen = req.body.historyLen;
    var screenWidth = req.body.screenWidth;
    var screenHeight = req.body.screenHeight;
    var cookie = req.body.cookie;
    var city = req.body.city;
    var state = req.body.state;
    var country = req.body.country;
    var mic;

    if(req.body.mic === "mic") {
        mic = "yes";
    } else {
        mic = "no";
    }
    var gamertag = req.body.gamertag;
    console.log("Captcha received:",captcha);
    var sql = `INSERT INTO games (platform, region, language, activity, skill, mic, gamertag, created_at, captcha, ip, userAgent, os, referrer, historyLen, screenWidth, screenHeight, cookie, city, state, country) VALUES 
("${platform}", "${region}", "${language}", "${activity}", "${skill}","${mic}","${gamertag}",NOW(),"${captcha}","${ip}","${userAgent}","${os}","${referrer}","${historyLen}","${screenWidth}","${screenHeight}","${cookie}","${city}","${state}","${country}")`;
    db.query(sql, function(err, result) {
        if (err) throw err;
        console.log('Record inserted',platform, region, language, activity, skill, mic, gamertag, ip);
        req.flash('success', 'Squad Request Sent!');
        res.redirect('/');
    });
});

app.use(function(req, res, next) {
    next(createError(404));
});

app.listen(3000, function () {
    console.log('Node app is running on port 3000');
});

module.exports = app;

