const puppeteer = require('puppeteer');
var db=require('../database');

(async () => {
    const browser = await puppeteer.launch({
        headless: false
    });
    const page = await browser.newPage();
    console.log("Navigating to wzranked.com");
    await page.goto('https://www.wzranked.com/', {    waitUntil: 'networkidle2',  });
    console.log("Waiting 5 seconds");
    try {
        var rank1 = await page.evaluate(() => {
            return document.querySelector("#app > div.layout > div.py-3.px-0.border-bottom.border-dark > div.small > div > div > div:nth-child(1) > div:nth-child(2) > div > div > div > div.col-6 > p > a").innerText
        });
        var rank2 = await page.evaluate(() => {
            return document.querySelector("#app > div.layout > div.py-3.px-0.border-bottom.border-dark > div.small > div > div > div:nth-child(1) > div:nth-child(3) > div > div > div > div.col-6 > p > a").innerText
        });
        var rank3 = await page.evaluate(() => {
            return document.querySelector("#app > div.layout > div.py-3.px-0.border-bottom.border-dark > div.small > div > div > div:nth-child(1) > div:nth-child(4) > div > div > div > div.col-6 > p > a").innerText
        });
        var rank4 = await page.evaluate(() => {
            return document.querySelector("#app > div.layout > div.py-3.px-0.border-bottom.border-dark > div.small > div > div > div:nth-child(1) > div:nth-child(5) > div > div > div > div.col-6 > p > a").innerText
        });
        var rank5 = await page.evaluate(() => {
            return document.querySelector("#app > div.layout > div.py-3.px-0.border-bottom.border-dark > div.small > div > div > div:nth-child(1) > div:nth-child(6) > div > div > div > div.col-6 > p > a").innerText
        });
    } catch (e) {
        console.log(e);
    }
    try {
        var rank1Ratio = await page.evaluate(() => {
            return document.querySelector("#app > div.layout > div.py-3.px-0.border-bottom.border-dark > div.small > div > div > div:nth-child(1) > div:nth-child(2) > div > div > div > div:nth-child(3) > p").innerText
        });
        var rank2Ratio = await page.evaluate(() => {
            return document.querySelector("#app > div.layout > div.py-3.px-0.border-bottom.border-dark > div.small > div > div > div:nth-child(1) > div:nth-child(3) > div > div > div > div:nth-child(3) > p").innerText
        });
        var rank3Ratio = await page.evaluate(() => {
            return document.querySelector("#app > div.layout > div.py-3.px-0.border-bottom.border-dark > div.small > div > div > div:nth-child(1) > div:nth-child(4) > div > div > div > div:nth-child(3) > p").innerText
        });
        var rank4Ratio = await page.evaluate(() => {
            return document.querySelector("#app > div.layout > div.py-3.px-0.border-bottom.border-dark > div.small > div > div > div:nth-child(1) > div:nth-child(5) > div > div > div > div:nth-child(3) > p").innerText
        });
        var rank5Ratio = await page.evaluate(() => {
            return document.querySelector("#app > div.layout > div.py-3.px-0.border-bottom.border-dark > div.small > div > div > div:nth-child(1) > div:nth-child(6) > div > div > div > div:nth-child(3) > p").innerText
        });
    } catch (e) {
        console.log(e);
    }
    try {
        var kd1 = await page.evaluate(() => {
            return document.querySelector("#app > div.layout > div.py-3.px-0.border-bottom.border-dark > div.small > div > div > div:nth-child(2) > div:nth-child(2) > div > div > div > div.col-6 > p > a").innerText
        });
        var kd2 = await page.evaluate(() => {
            return document.querySelector("#app > div.layout > div.py-3.px-0.border-bottom.border-dark > div.small > div > div > div:nth-child(2) > div:nth-child(3) > div > div > div > div.col-6 > p > a").innerText
        });
        var kd3 = await page.evaluate(() => {
            return document.querySelector("#app > div.layout > div.py-3.px-0.border-bottom.border-dark > div.small > div > div > div:nth-child(2) > div:nth-child(4) > div > div > div > div.col-6 > p > a").innerText
        });
        var kd4 = await page.evaluate(() => {
            return document.querySelector("#app > div.layout > div.py-3.px-0.border-bottom.border-dark > div.small > div > div > div:nth-child(2) > div:nth-child(5) > div > div > div > div.col-6 > p > a").innerText
        });
        var kd5 = await page.evaluate(() => {
            return document.querySelector("#app > div.layout > div.py-3.px-0.border-bottom.border-dark > div.small > div > div > div:nth-child(2) > div:nth-child(6) > div > div > div > div.col-6 > p > a").innerText
        });
    } catch (e) {
        console.log(e);
    }
    try {
        var kd1Ratio = await page.evaluate(() => {
            return document.querySelector("#app > div.layout > div.py-3.px-0.border-bottom.border-dark > div.small > div > div > div:nth-child(2) > div:nth-child(2) > div > div > div > div:nth-child(3) > p").innerText
        });
        var kd2Ratio = await page.evaluate(() => {
            return document.querySelector("#app > div.layout > div.py-3.px-0.border-bottom.border-dark > div.small > div > div > div:nth-child(2) > div:nth-child(3) > div > div > div > div:nth-child(3) > p").innerText
        });
        var kd3Ratio = await page.evaluate(() => {
            return document.querySelector("#app > div.layout > div.py-3.px-0.border-bottom.border-dark > div.small > div > div > div:nth-child(2) > div:nth-child(4) > div > div > div > div:nth-child(3) > p").innerText
        });
        var kd4Ratio = await page.evaluate(() => {
            return document.querySelector("#app > div.layout > div.py-3.px-0.border-bottom.border-dark > div.small > div > div > div:nth-child(2) > div:nth-child(5) > div > div > div > div:nth-child(3) > p").innerText
        });
        var kd5Ratio = await page.evaluate(() => {
            return document.querySelector("#app > div.layout > div.py-3.px-0.border-bottom.border-dark > div.small > div > div > div:nth-child(2) > div:nth-child(6) > div > div > div > div:nth-child(3) > p").innerText
        });
    } catch (e) {
        console.log(e);
    }
    await browser.close();
    var sql = `INSERT INTO topweapons (marker,rank1,rank2,rank3,rank4,rank5,rank1Ratio,rank2Ratio,rank3Ratio,rank4Ratio,rank5Ratio,kd1,kd2,kd3,kd4,kd5,kd1Ratio,kd2Ratio,kd3Ratio,kd4Ratio,kd5Ratio,created_at) VALUES ("1","${rank1}", "${rank2}", "${rank3}", "${rank4}", "${rank5}", "${rank1Ratio}", "${rank2Ratio}", "${rank3Ratio}", "${rank4Ratio}", "${rank5Ratio}", "${kd1}", "${kd2}", "${kd3}", "${kd4}", "${kd5}", "${kd1Ratio}", "${kd2Ratio}", "${kd3Ratio}", "${kd4Ratio}", "${kd5Ratio}",NOW())`;
    var sqlDELETE = `DELETE FROM topweapons WHERE topweapons.marker = 1`;

    try {
        await db.query(sqlDELETE, function (err, result, fields) {
            if (err) throw err;
            console.log("Deleted most recent block");
        });
    } catch (e) {}
    await db.query(sql, function(err, result) {
        if (err) throw err;
        console.log('Records inserted into topweapons DB');
        console.log(rank1,rank2,rank3,rank4,rank5);
        console.log(rank1Ratio,rank2Ratio,rank3Ratio,rank4Ratio,rank5Ratio);
        console.log(kd1,kd2,kd3,kd4,kd5);
        console.log(kd1Ratio,kd2Ratio,kd3Ratio,kd4Ratio,kd5Ratio);
        process.exit();
    });

})();

